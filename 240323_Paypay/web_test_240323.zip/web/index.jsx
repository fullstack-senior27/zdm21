const { useState } = React;
const { render } = ReactDOM;

function App() {
  // countという状態変数と、その状態を更新するための関数setCountを定義します
  const [count, setCount] = useState(0);

  // +1ボタンがクリックされたときの処理を定義します
  const handleAdd = () => {
    // setCountを使ってcountを更新します。Math.minを使って、更新後のcountが100を超えないようにします
    setCount(prevCount => Math.min(prevCount + 1, 100));
  };

  // -1ボタンがクリックされたときの処理を定義します
  const handleSubtract = () => {
    // setCountを使ってcountを更新します。Math.maxを使って、更新後のcountが0未満にならないようにします
    setCount(prevCount => Math.max(prevCount - 1, 0));
  };

  // *2ボタンがクリックされたときの処理を定義します
  const handleMultiply = () => {
    // setCountを使ってcountを更新します。Math.minを使って、更新後のcountが100を超えないようにします
    setCount(prevCount => Math.min(prevCount * 2, 100));
  };

  // JSXを返して、表示される内容を定義します
  return (
    <div className="container">
      {/* ボタン群 */}
      <div className="buttons">
        {/* 各ボタンのイベントハンドラを指定します */}
        <button id="add" onClick={handleAdd}>+1</button>
        <button id="sub" onClick={handleSubtract}>-1</button>
        <button id="mul" onClick={handleMultiply}>*2</button>
      </div>
      {/* 表示用のdiv */}
      <div id="display" className="display">{count}</div>
    </div>
  );
}

// ReactDOM.renderでAppコンポーネントをroot要素にレンダリングします
ReactDOM.render(<App />, document.getElementById('root'));
